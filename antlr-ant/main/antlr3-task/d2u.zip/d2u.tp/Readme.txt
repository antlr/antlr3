The little grammar d2u.g splits lines and line breaks into separate parts.
Than stringtemplates are used to copy (echo) the line parts to the output.
Line breaks are transformed into the format (unix, dos, mac)
specified on the commandline before writing them to the output.
If no format is specified a conversion to unix style line breaks is done.

How to build and run the d2u example:

Extact the content of the archive d2u.zip.

It should create the following directory layout:

  +- d2u
     +- grammar
     +- src
     
Prerequisites:

1) Java version 1.5 or higher installed
2) Antlr installed
3) Environment variable ANTLR_HOME defined. ANTLR_HOME should
   point to the installation directory of Antlr.
4) At least apache ant version 1.7 or newer correctly installed and working
5) The antlr3 task for antlr has been installed. This usually means
   the antlr3.jar archive has been copied to the apache ant lib directory

Building and running the example:

1) Go into the d2u directory
2) Type:
   ant run
   
Remarks:

The ANTLR_HOME environment variable is a central
element of the build file. It is being used to
compose a path to the Antlr libraries.
The pattern defined to reference the Antlr libraries
is using wild cards. Therefore no changes of the buid
file should be necessary if a new version of Antlr
is intalled on your computer. Just let ANTLR_HOME
point to the new installation and you are done.
The relevant excerpt of the build file is listed here:

    <!-- Inquire environment variables -->
    <property environment="envList"/>

    <!-- Get environment variable ANTLR_HOME -->
    <property name="antlrHome" value="${envList.ANTLR_HOME}"/>
    
    <!-- Use wildcards in pattern definition -->
    <!-- to be independent of antlr versions -->
    <patternset id="antlr.libs">
        <include name="antlr-*.jar" />
        <include name="stringtemplate-*.jar" />
        <include name="runtime-*.jar" />
    </patternset>
    
    <!-- Looking for archives in ANTLR_HOME/lib -->
    <path id="antlr.path">
        <fileset dir="${antlrHome}/lib" casesensitive="yes">
            <patternset refid="antlr.libs" />
        </fileset>
    </path>   
    
The path "antlr.path" is than referenced in the classpath
directive various times.

Another possible point of interest is the jvmarg directive,
which is used in the antlr3 macro definition.
It passes the specified jvm args to the java machine, when Antlr
is executed. In the example below the maximum heap size is set
to 512 Megabytes.

    <jvmarg value="-Xmx512M"/>

The d2u.g grammar is not a aimed to be the basis of full grown
bullet proof tool for the conversion of line break formats.
It works quite well for small files, but when applied to real big
files (some megabytes or larger in size) than it probably
will get slow. This behaviour is owed to the standard mechanism of
Antlr to read the complete input file by the lexer and tokenize it
before invoking the parser. This standard behaviour can of course
be overriden (see the Antlr documentation). 

Running the programm manually for a conversion to mac line breaks:

java -classpath %ANTLR_HOME%/lib/antlr-runtime-3.1.jar;
 %ANTLR_HOME%/lib/antlr-2.7.7.jar;
 %ANTLR_HOME%/lib/stringtemplate-3.2.jar;dist/d2u.jar
 org.myorg.d2u.Main mac <d2u.stg >tmp.lis
