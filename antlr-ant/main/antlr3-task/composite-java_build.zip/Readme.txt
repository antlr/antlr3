How to build and run the composite-java example:

Extact the content of the archive composite-java-build.zip into the
composite-java directory of the java/composite-java example.
   
Prerequisites:

1) Java version 1.5 or higher installed
2) Antlr installed
3) Environment variable ANTLR_HOME defined. ANTLR_HOME should
   point to the installation directory of Antlr.
4) At least apache ant version 1.7 or newer correctly installed and working
5) The antlr3 task for antlr has been installed. This usually means
   the antlr3.jar archive has been copied to the apache ant lib directory

Building and running the example:

1) Go into the composite-java directory
2) Type:
   ant all
   
Remarks:

The ANTLR_HOME environment variable is a central
element of the build file. It is being used to
compose a path to the Antlr libraries.
The pattern defined to reference the Antlr libraries
is using wild cards. Therefore no changes of the buid
file should be necessary if a new version of Antlr
is intalled on your computer. Just let ANTLR_HOME
point to the new installation and you are done.
The relevant excerpt of the build file is listed here:

    <!-- Inquire environment variables -->
    <property environment="envList"/>

    <!-- Get environment variable ANTLR_HOME -->
    <property name="antlrHome" value="${envList.ANTLR_HOME}"/>
    
    <!-- Use wildcards in pattern definition -->
    <!-- to be independent of antlr versions -->
    <patternset id="antlr.libs">
        <include name="antlr-*.jar" />
        <include name="stringtemplate-*.jar" />
        <include name="runtime-*.jar" />
    </patternset>
    
    <!-- Looking for archives in ANTLR_HOME/lib -->
    <path id="antlr.path">
        <fileset dir="${antlrHome}/lib" casesensitive="yes">
            <patternset refid="antlr.libs" />
        </fileset>
    </path>   
    
The path "antlr.path" is then referenced in the classpath
directive various times.

Another possible point of interest is the jvmarg directive,
which is used in the antlr3 macro definition.
It passes the specified jvm args to the java machine, when Antlr
is executed. In the example below the maximum heap size is set
to 512 Megabytes.

    <jvmarg value="-Xmx512M"/>

